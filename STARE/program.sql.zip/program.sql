-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 21, 2015 at 07:56 PM
-- Server version: 5.5.32
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `program`
--
CREATE DATABASE IF NOT EXISTS `program` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `program`;

-- --------------------------------------------------------

--
-- Table structure for table `punkt_rodzaj`
--

CREATE TABLE IF NOT EXISTS `punkt_rodzaj` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `punkt_rodzaj` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `punkt_rodzaj`
--

INSERT INTO `punkt_rodzaj` (`id`, `punkt_rodzaj`) VALUES
(1, 'TSSK Czytanie Biblii'),
(2, 'TSSK Nr 1'),
(3, 'TSSK Nr 2'),
(4, 'TSSK Nr 3'),
(5, 'NSK Nr 1'),
(6, 'NSK Nr 2'),
(7, 'NSK Nr 3'),
(8, 'NSK Nr 4'),
(9, 'TSSK Powtórka');

-- --------------------------------------------------------

--
-- Table structure for table `tydzien`
--

CREATE TABLE IF NOT EXISTS `tydzien` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tydzien_od_data` date NOT NULL,
  `czy_powtorka` tinyint(1) NOT NULL,
  `piesn_1` int(11) NOT NULL,
  `piesn_2` int(11) NOT NULL,
  `piesn_3` int(11) NOT NULL,
  `zsb_publikacja` varchar(255) NOT NULL,
  `zsb_material` varchar(50) NOT NULL,
  `zsb_czas` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UX_tydzien` (`tydzien_od_data`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `tydzien`
--

INSERT INTO `tydzien` (`id`, `tydzien_od_data`, `czy_powtorka`, `piesn_1`, `piesn_2`, `piesn_3`, `zsb_publikacja`, `zsb_material`, `zsb_czas`) VALUES
(6, '2015-07-20', 0, 73, 89, 66, 'cl', 'rozdz. 27, ak. 19-22, ramka na s. 279', 30),
(7, '2015-07-27', 0, 18, 65, 125, 'cl', 'rozdz. 28, ak. 1-9', 30),
(8, '2015-08-03', 0, 63, 130, 26, 'cl', 'rozdz. 28, ak. 10-17', 30),
(9, '2015-08-10', 0, 61, 41, 93, 'cl', 'rozdz. 28, ak. 18-21, ramka na s. 289', 30),
(10, '2015-08-17', 0, 5, 52, 88, 'cl', 'rozdz. 29, ak. 1-10', 30),
(11, '2015-08-24', 0, 21, 40, 130, 'cl', 'rozdz. 29, ak. 11-15', 30),
(12, '2015-08-31', 1, 42, 95, 10, 'cl', 'rozdz. 29, ak. 16-21, ramka na s. 299', 30),
(13, '2015-09-07', 0, 3, 89, 118, 'cl', 'rozdz. 30, ak. 1-9', 30),
(14, '2015-09-14', 0, 50, 23, 96, 'cl', 'rozdz. 30, ak. 10-18', 30),
(15, '2015-09-21', 0, 53, 97, 81, 'cl', 'rozdz. 30, ak. 19-23, ramka na s. 309', 30),
(16, '2015-09-28', 0, 73, 93, 114, 'cl', 'rozdz. 31, ak. 1-12', 30),
(18, '2015-10-05', 0, 13, 82, 98, 'cl', 'rozdz. 31, ak. 13-20', 30);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `first_name`, `last_name`, `address`) VALUES
(1, 'lucentx', 'Aron', 'Barbosa', 'Manila, Philippines'),
(2, 'ozzy', 'Ozzy', 'Osbourne', 'England'),
(3, 'tony', 'Tony', 'Iommi', 'England');

-- --------------------------------------------------------

--
-- Table structure for table `zebranie_w_tygodniu_punkty`
--

CREATE TABLE IF NOT EXISTS `zebranie_w_tygodniu_punkty` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tydzien_id` int(11) NOT NULL,
  `punkt_rodzaj_id` int(11) NOT NULL,
  `punkt_temat` varchar(255) NOT NULL,
  `punkt_czas` int(11) NOT NULL,
  `punkt_opis` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `X1_nr_zebrania` (`tydzien_id`,`punkt_rodzaj_id`),
  KEY `X2_rodzaj_punktu` (`punkt_rodzaj_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=99 ;

--
-- Dumping data for table `zebranie_w_tygodniu_punkty`
--

INSERT INTO `zebranie_w_tygodniu_punkty` (`id`, `tydzien_id`, `punkt_rodzaj_id`, `punkt_temat`, `punkt_czas`, `punkt_opis`) VALUES
(17, 6, 1, '1 Królów 12-14', 8, ''),
(18, 6, 2, '1 Królów 12:21-30', 3, ''),
(19, 6, 3, 'Daniel: Jehowa błogosławi służbie pełnionej całą duszą (it-1 ss. 431-433, Daniel nr 2)', 5, ''),
(20, 6, 4, 'Jak Biblia może pomóc mężom i ojcom? (igw s. 26, ak. 1, 2)', 5, ''),
(21, 6, 5, 'Korzystaj z ilustrowanych historii biblijnych, żeby pomóc swoim dzieciom stać się uczniami Chrystusa', 20, 'Omówienie z udziałem obecnych ilustrowanej historii biblijnej „Bóg posyła Mojżesza do Egiptu” (patrz w serwisie jw.org: NAUKI BIBLIJNE &gt; DZIECI). Wyświetl ją na ekranie, żeby wszyscy mogli śledzić treść. Jeśli to możliwe, niech kilkoro wyznaczonych wcześniej dzieci przeczyta tekst z podziałem na role. Następnie, za zgodą rodziców, zaproś na scenę wybrane dzieci, żeby wspólnie z nimi omówić pytania z ramki „Czego się uczymy z tej historii?”. Na zakończenie zachęć rodziców, by korzystali z tej kolekcji materiałów.'),
(22, 6, 6, 'Skrzynka pytań', 10, 'Omówienie z udziałem obecnych. Rozważając drugi akapit, przypomnij, że nie posługujemy się już formularzem S-43.'),
(23, 7, 1, '1 Królów 15-17', 8, ''),
(24, 7, 2, '1 Królów 15:16-24', 3, ''),
(25, 7, 3, 'Jak Biblia może pomóc żonom? (igw s. 26, ak. 3, 4)', 5, ''),
(26, 7, 4, 'Dawid: Młodzi, przygotowujcie się, żeby odważnie służyć Jehowie (it-1 ss. 451-456)', 5, ''),
(27, 7, 5, 'Czy podnosisz jakość swojej służby?', 10, 'Omówienie z udziałem obecnych. Zwróć uwagę na cel artykułów „Podnośmy jakość swojej służby” (zob. Naszą Służbę Królestwa z lutego 2014 roku, s. 1, ak. 1). Krótko przypomnij niektóre z nich. Poproś obecnych, by powiedzieli, jakie konkretne korzyści odnieśli z tej serii. Zachęć głosicieli, żeby każdego miesiąca starali się stosować do wskazówek podawanych pod nagłówkiem „Wypróbuj przez najbliższy miesiąc”.'),
(28, 7, 6, 'Korzystaj z broszury Poznaj Słowo Boże podczas studiów biblijnych', 10, 'Omówienie z udziałem obecnych. Rozważcie, jak za pomocą następujących fragmentów broszury nauczyć zainteresowanego korzystać z Biblii: 1) „Jak odszukiwać wersety biblijne?”; 2) pytanie 19: „Co zawierają poszczególne księgi biblijne?”; 3) pytanie 20: „Jak odnieść najwięcej pożytku z czytania Biblii?”. Wprowadź krótki pokaz, w którym głosiciel pod koniec studium omawia z zainteresowanym jeden z wymienionych fragmentów.'),
(29, 7, 7, '„Nasze narzędzia”', 10, 'Pytania i odpowiedzi.'),
(30, 8, 1, '1 Królów 18-20', 8, ''),
(31, 8, 2, '1 Królów 18:30-40', 3, ''),
(32, 8, 3, 'Debora: Wierne kobiety wysławiają Jehowę (it-1 s. 458, Debora nr 2)', 5, ''),
(33, 8, 4, 'Jak Biblia może pomóc dzieciom? (igw s. 27, ak. 1, 2)', 5, ''),
(34, 8, 5, 'Proponowanie czasopism w sierpniu', 10, 'Omówienie z udziałem obecnych. Na początku wprowadź pokazy ilustrujące, jak można wykorzystać dwie propozycje z tej strony. Następnie przeanalizuj całą treść tych propozycji.'),
(35, 8, 6, 'Odnoś pożytek z broszury Codzienne badanie Pism', 10, 'Omówienie z udziałem obecnych. Zacznij od pięciominutowego przemówienia opartego na myśli przewodniej na rok 2015. Potem poproś obecnych, by powiedzieli, kiedy rozważają tekst dzienny. Na zakończenie zachęć wszystkich do korzystania z broszury Codzienne badanie Pism.'),
(36, 8, 7, 'Potrzeby zboru.', 10, ''),
(37, 9, 1, '1 Królów 21, 22', 8, ''),
(38, 9, 2, '1 Królów 22:13-23', 3, ''),
(39, 9, 3, 'Jak przybliżać się do Boga? (igw s. 28, ak. 1-4)', 5, ''),
(40, 9, 4, 'Dalila: Umiłowanie pieniędzy może popchnąć do zdrady (it-1 ss. 426, 427)', 5, ''),
(41, 9, 5, '„Ja i mój dom będziemy służyć Jehowie”', 10, 'Przemówienie oparte na haśle miesiąca. Odczytaj wersety z Powtórzonego Prawa 6:6, 7, Jozuego 24:15 oraz Przysłów 22:6 i wskaż na ich zastosowanie. Uwypuklij, że mężowie i ojcowie muszą przewodzić pod względem duchowym. Przypomnij, jakie narzędzia dla rodzin dostarcza organizacja Jehowy. Zwróć uwagę na wybrane punkty zebrań służby i podkreśl, jak wiążą się z hasłem miesiąca.'),
(42, 9, 6, '„Podnośmy jakość swojej służby: Szkolenie nowych głosicieli”', 20, 'Omówienie z udziałem obecnych. Poproś zebranych, żeby powiedzieli, jak rodzice mogą wykorzystać wskazówki podane w tym artykule do pomagania swoim dzieciom. Wprowadź pokaz, w którym ojciec z dzieckiem przygotowują razem wstęp.'),
(43, 10, 1, '2 Królów 1-4', 8, ''),
(44, 10, 2, '2 Królów 1:11-18', 3, ''),
(45, 10, 3, 'Dina: Obracanie się w złym towarzystwie może doprowadzić do tragedii (it-1 s. 468)', 5, ''),
(46, 10, 4, 'Co robić, żeby przybliżać się do Boga? (igw s. 28, ak. 5, do s. 29, ak. 3)', 5, ''),
(47, 10, 5, '„Te słowa (...) mają być w twoim sercu”', 30, 'Pytania i odpowiedzi. Wykorzystaj informacje z pierwszego i ostatniego akapitu jako krótki wstęp i zakończenie.'),
(48, 11, 1, '2 Królów 5-8', 8, ''),
(49, 11, 2, '2 Królów 6:20-31', 3, ''),
(50, 11, 3, 'Co zawierają poszczególne księgi Pism Hebrajskich? (igw s. 30)', 5, ''),
(51, 11, 4, 'Doeg: Wystrzegaj się tych, którzy miłują zło (it-1 s. 477)', 5, ''),
(52, 11, 5, 'Potrzeby zboru.', 15, ''),
(53, 11, 6, 'Jak podnosić jakość wielbienia Boga w gronie rodziny?', 15, 'Omówienie z udziałem obecnych myśli z Naszej Służby Królestwa ze stycznia 2011 roku, strona 6. Pokaż materiały na rodzinne wielbienie Boga udostępnione w serwisie jw.org (patrz'),
(54, 12, 1, '2 Królów 9-11', 8, ''),
(55, 12, 9, '', 20, ''),
(56, 12, 5, 'Proponowanie czasopism we wrześniu', 10, 'Omówienie z udziałem obecnych. Na początku wprowadź pokazy ilustrujące, jak można wykorzystać dwie propozycje z następnej strony. Następnie przeanalizuj całą treść tych propozycji.'),
(57, 12, 6, 'Czy otrzymujesz „pokarm we właściwym czasie”?', 10, 'Przemówienie oparte na artykule ze Strażnicy z 15 sierpnia 2014 roku, strony 3-5. Zachęć wszystkich, by robili dobry użytek z dostępnego pokarmu duchowego.'),
(58, 12, 7, 'Jakie masz cele duchowe na rok służbowy 2016?', 10, 'Omówienie z udziałem obecnych materiału z książki Zorganizowani, strona 118, akapit 2. Wprowadź pokaz, w którym małżeństwo wyznacza sobie cele duchowe na nowy rok służbowy.'),
(59, 13, 1, '2 Królów 12-15', 8, ''),
(60, 13, 2, '2 Królów 13:12-19', 3, ''),
(61, 13, 3, 'Dorkas: Prawdziwi chrześcijanie obfitują w dobre uczynki (it-1 s. 483)', 5, ''),
(62, 13, 4, 'Co zawierają poszczególne księgi Chrześcijańskich Pism Greckich? (igw s. 31)', 5, ''),
(63, 13, 5, 'Co udało się nam osiągnąć?', 10, 'Punkt z udziałem obecnych. Poproś, by opowiedzieli, jakie korzyści odnieśli z zastosowania wskazówek podanych w artykule „Podnośmy jakość swojej służby'),
(64, 13, 6, 'Czy wasza rodzina regularnie chodzi na zebrania?', 10, 'Przemówienie oparte na Hebrajczyków 10:24, 25. Przeprowadź wywiad z rodziną z dziećmi. Jak ojciec dba o to, żeby rodzina dawała zebraniom pierwszeństwo? Jak każdy przyczynia się do regularnej obecności na zebraniach? Kiedy przygotowują odpowiedzi? Na jakie ofiary się zdobywają, żeby być obecni? Na zakończenie zachęć wszystkich, by regularnie przychodzili na zebrania i brali w nich udział.'),
(65, 13, 7, 'Czy siejesz ziarno prawdy w swojej rodzinie?', 10, '(Dzieje 10:24, 33, 48). Omówienie z udziałem obecnych materiału z Rocznika — 2015, strona 87, akapity 1 i 2, oraz strona 90, akapity 1-3. Poproś obecnych, by powiedzieli, czego się nauczyli z tych relacji.'),
(66, 14, 1, '2 Królów 16-18', 8, ''),
(67, 14, 2, '2 Królów 17:12-18', 3, ''),
(68, 14, 3, 'Jak odnieść najwięcej pożytku z czytania Biblii? (igw s. 32)', 5, ''),
(69, 14, 4, 'Ebed-Melech: Bądź nieustraszony i szanuj sług Jehowy (it-1 s. 548)', 5, ''),
(70, 14, 5, '‛Składajmy dokładne świadectwo na rzecz dobrej nowiny’', 10, 'Przemówienie oparte na haśle miesiąca oraz książce Składajmy świadectwo, rozdział 1, akapity 1-11 (Dzieje 20:24).'),
(71, 14, 6, '„Podnośmy jakość swojej służby: Głoszenie na terenach handlowo-usługowych”', 20, 'Omówienie z udziałem obecnych. Wprowadź krótki dwuczęściowy pokaz. Głosiciel stara się dać świadectwo jakiejś osobie w jej miejscu pracy. Za pierwszym razem robi to nieumiejętnie, a za drugim przejawia rozeznanie. Poproś obecnych, żeby powiedzieli, dlaczego druga rozmowa była lepsza.'),
(72, 15, 1, '2 Królów 19-22', 8, ''),
(73, 15, 2, '2 Królów 20:12-21', 3, ''),
(74, 15, 3, 'Ehud: Jehowa wybawia swój lud (it-1 ss. 581, 582, Ehud nr 2)', 5, ''),
(75, 15, 4, 'Co oznacza słowo „amen”?', 5, ''),
(76, 15, 5, 'Co osiągnęliśmy w minionym roku służbowym?', 10, 'Przemówienie nadzorcy służby. Krótko omów działalność zboru w minionym roku służbowym. Podkreśl pozytywne wyniki i udziel stosownych pochwał. Wspomnij o jednej lub dwóch dziedzinach służby, w których zbór mógłby zrobić postępy w bieżącym roku, i podaj praktyczne wskazówki, jak to osiągnąć.'),
(77, 15, 6, 'Składanie dokładnego świadectwa przynosi rezultaty', 10, 'Omówienie z udziałem obecnych materiału z Rocznika — 2015, strona 54, akapit 1, od strony 56, akapit 2, do strony 57, akapit 1, oraz od strony 63, akapit 2, do strony 64, akapit 1. Po omówieniu każdej relacji poproś obecnych, by powiedzieli, czego się z niej nauczyli.'),
(78, 15, 7, '„Naśladujmy ich wiarę”', 10, 'Pytania i odpowiedzi.'),
(79, 16, 1, '2 Królów 23-25', 8, ''),
(80, 16, 2, '2 Królów 23:8-15', 3, ''),
(81, 16, 3, 'Jaką rolę w zamierzeniu Bożym odgrywają aniołowie?', 5, ''),
(82, 16, 4, 'Eleazar: Niezłomnie służ Jehowie (it-1 ss. 586, 587, Eleazar nr 1)', 5, ''),
(83, 16, 5, 'Paweł i jego towarzysze składają dokładne świadectwo w Filippi', 10, 'Omówienie z udziałem obecnych. Poproś o odczytanie Dziejów 16:11-15. Rozważcie, pod jakim względem podane wersety mogą nam pomóc w naszej służbie.'),
(84, 16, 6, '„Posługiwanie się broszurą Bóg ma dobrą nowinę”', 20, 'Pytania i odpowiedzi. Po omówieniu akapitu 3 wprowadź dobrze przygotowany pokaz, w którym głosiciel proponuje broszurę Bóg ma dobrą nowinę i omawia jeden akapit.'),
(92, 18, 1, '1 Kronik 1-4', 8, ''),
(93, 18, 2, '1 Kronik 1:28-42', 3, ''),
(94, 18, 3, 'Heli: Pobłażliwość zniesławia Jehowę (it-1 ss. 804, 805, Heli nr 1)', 5, ''),
(95, 18, 4, 'Do kogo odnosi się określenie „antychryst”?', 5, ''),
(96, 18, 5, 'Proponowanie czasopism w październiku', 10, 'Omówienie z udziałem obecnych. Na początku wprowadź pokazy ilustrujące, jak można wykorzystać dwie propozycje z tej strony. Następnie przeanalizujcie całą treść tych propozycji.'),
(97, 18, 6, 'Potrzeby zboru.', 10, ''),
(98, 18, 7, 'Co udało się nam osiągnąć?', 10, 'Punkt z udziałem obecnych. Poproś głosicieli, by opowiedzieli, jakie korzyści odnieśli z zastosowania wskazówek podanych w artykule „Podnośmy jakość swojej służby');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `zebranie_w_tygodniu_punkty`
--
ALTER TABLE `zebranie_w_tygodniu_punkty`
  ADD CONSTRAINT `zebranie_w_tygodniu_punkty_ibfk_1` FOREIGN KEY (`tydzien_id`) REFERENCES `tydzien` (`id`),
  ADD CONSTRAINT `zebranie_w_tygodniu_punkty_ibfk_2` FOREIGN KEY (`punkt_rodzaj_id`) REFERENCES `punkt_rodzaj` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
